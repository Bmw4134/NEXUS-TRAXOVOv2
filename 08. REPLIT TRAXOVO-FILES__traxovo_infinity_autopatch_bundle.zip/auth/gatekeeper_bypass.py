def bypass_for_agent(agent_id):
    allowed_agents = ["BMI_HARDWORKER", "INFINITY_DEPLOYER"]
    return agent_id in allowed_agents
